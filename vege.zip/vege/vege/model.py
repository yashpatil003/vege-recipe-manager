from django.db import models

class Recepies(models.Model):
    recipe_name =models.CharField(max_length=100) 
    recipe_description =models.TextField()
    recipe_image = models.ImageField(upload_to="recipe")
    recipe_video = models.FileField(upload_to="recipe_video" ,null=True,blank=True)


    
